from app_sasquatch import app
from app_sasquatch.controladores import controlador_usuario, controlador_avistamientos

if __name__ == "__main__":
    app.run (debug = True, port=5001)