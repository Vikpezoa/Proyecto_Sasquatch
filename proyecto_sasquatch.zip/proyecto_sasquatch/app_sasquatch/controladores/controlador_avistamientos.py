from flask import Flask, render_template, request, session, redirect
from app_sasquatch import app
from app_sasquatch.modelos.modelo_avistamiento import Avistamiento
from datetime import datetime

@app.route('/dashboard') 
def desplegar_avistamientos():
    if "id_usuario" not in session:
        return redirect( '/' )
    else:
        lista_avistamientos = Avistamiento.obtener_todos_con_usuario()
        return render_template('avistamientos.html', lista_avistamientos=lista_avistamientos)
#necesitamos en el html importar una tabla para mostrarlas mediante ciclo

@app.route( '/nuevo/avistamiento')
def desplegar_formulario_avistamiento():
    if "id_usuario" not in session:
        return redirect( '/' )
    else:
        return render_template( 'formulario_avistamiento.html' )

@app.route( '/crear/avistamiento', methods = ['POST'] )
def nuevo_avistamiento():
    data = {
        **request.form,
        "id_usuario" : session['id_usuario']
    }
    if Avistamiento.validar_formulario_avistamientos( data ) == False:
        return redirect( '/nuevo/avistamiento' )
    else:
        id_avistamiento = Avistamiento.crear_uno( data )
        return redirect( '/dashboard' ) 
    
    #UTIL PARA VER SI LLEGA LA DATA: print(request.form) ->luego de completar los casilleros del sitio.

@app.route('/eliminar/avistamiento/<int:id>', methods=['POST'])
def eliminar_avistamiento(id):
    data={
        "id":id
    }
    Avistamiento.elimina_uno(data)
    return redirect('/dashboard')


@app.route('/avistamiento/<int:id>')
def desplegar_avistamiento(id):
    if "id_usuario" not in session:
        return redirect( '/' )
    else:
        data={
            "id":id
        }
        avistamiento=Avistamiento.obtener_uno_con_usuario(data)
        return render_template('avistamiento.html',avistamiento=avistamiento) 

@app.route('/editar/avistamiento/<int:id>')
def desplegar_editar_avistamiento(id):
    if "id_usuario" not in session:
        return redirect( '/' )
    else:
        data = {
            "id" : id
        }

        avistamiento=Avistamiento.obtener_uno(data)
         #OBTENER UNO CON USUARIO NO, OBTENER UNO, PUESTO QUE SOLO SE PUEDE EDITAR CON EL MISMO USUARIO, NO CON CUALQUIERA.
        return render_template('editar_avistamiento.html',avistamiento=avistamiento)


@app.route('/editar/avistamiento/<int:id>',methods=['POST'])
def editar_avistamiento( id ):
    if Avistamiento.validar_formulario_avistamientos( request.form ) == False:
        return redirect( f'/editar/avistamiento/{id}' )
    else:
        data = {
            **request.form,
            "id" : id
        }
        Avistamiento.editar_uno( data )
        return redirect( '/dashboard' )
    