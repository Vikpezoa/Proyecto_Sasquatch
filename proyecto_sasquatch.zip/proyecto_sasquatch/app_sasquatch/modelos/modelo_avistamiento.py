from app_sasquatch.config.mysqlconnection import connectToMySQL
from app_sasquatch import BASE_DATOS
from app_sasquatch.modelos.modelo_usuario import Usuario
from flask import flash

class Avistamiento:
    def __init__(self, data):
        self.id = data['id']
        self.localidad = data['localidad']
        self.descripcion = data['descripcion']
        self.fecha_observacion = data['fecha_observacion']
        self.sasquatches = data['sasquatches']
        self.fecha_creacion = data['fecha_creacion']
        self.fecha_actualizacion = data['fecha_actualizacion']
        self.id_usuario = data['id_usuario']
        self.usuario = None #Recordamos la relacion existente entre los database
    
    @classmethod
    def obtener_nombre_mes(self):
        # Obtenemos el nombre del mes a partir del número del mes (1 a 12)
        meses = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre']
        numero_mes = self.fecha_observacion.month
        nombre_mes = meses[numero_mes - 1]
        return nombre_mes 

    @classmethod
    def crear_uno(cls, data):
        query= """
                INSERT INTO avistamientos (localidad, descripcion,fecha_observacion,sasquatches,id_usuario)
                VALUES (%(localidad)s, %(descripcion)s,%(fecha_observacion)s,%(sasquatches)s,%(id_usuario)s)
                """
        id_avistamiento= connectToMySQL(BASE_DATOS).query_db(query,data)
        return id_avistamiento
    
    @classmethod
    def obtener_todos_con_usuario(cls):
        query="""
                SELECT *
                FROM avistamientos a JOIN usuarios u
                    ON a.id_usuario = u.id;
                """
        resultado = connectToMySQL(BASE_DATOS).query_db(query) #data no es necesario porque agarramos todo
        lista_avistamientos=[] 
        for renglon in resultado:
            avistamiento= Avistamiento(renglon)
            data_usuario={ #creo instancia de usuario
                "id": renglon['u.id'],
                "nombre": renglon['nombre'],
                "apellido": renglon['apellido'],
                "email": renglon['email'],
                "password":renglon['password'], 
                "fecha_creacion": renglon['u.fecha_creacion'],
                "fecha_actualizacion": renglon['u.fecha_actualizacion']
            }
            usuario=Usuario(data_usuario)
            avistamiento.usuario=usuario
            lista_avistamientos.append(avistamiento)
        return lista_avistamientos
    
    @classmethod
    def elimina_uno(cls,data):
        query="""
                DELETE FROM AVISTAMIENTOS
                WHERE id= %(id)s;
                """
        return connectToMySQL(BASE_DATOS).query_db(query,data)

    @classmethod
    def obtener_uno(cls,data):
        query="""
                SELECT * FROM AVISTAMIENTOS
                WHERE id=%(id)s
                """
        resultado=connectToMySQL(BASE_DATOS).query_db(query,data)
        avistamiento = Avistamiento(resultado[0])
        return avistamiento
    
    @classmethod
    def editar_uno(cls,data):
        query="""
                UPDATE avistamientos
                SET localidad=%(localidad)s,descripcion=%(descripcion)s,fecha_observacion=%(fecha_observacion)s,sasquatches=%(sasquatches)s
                WHERE id= %(id)s;
                """
        return connectToMySQL(BASE_DATOS).query_db(query,data)

   
    

    @classmethod
    def obtener_uno_con_usuario( cls, data ):
        query = """
                SELECT *
                FROM avistamientos a JOIN usuarios u
                ON a.id_usuario = u.id
                WHERE a.id = %(id)s;
                """
        resultado = connectToMySQL( BASE_DATOS ).query_db( query, data )
        renglon = resultado[0]
        avistamiento = Avistamiento( renglon )
        data_usuario = {
            "id" : renglon['u.id'],
            "nombre" : renglon['nombre'],
            "apellido" : renglon['apellido'],
            "email" : renglon['email'],
            "password" : renglon['password'],
            "fecha_creacion" : renglon['u.fecha_creacion'],
            "fecha_actualizacion" : renglon['u.fecha_actualizacion']
        }
        avistamiento.usuario = Usuario( data_usuario )
        return avistamiento
    
    def fecha_con_formato(self):
        return self.fecha_observacion.strftime('%d/%m/%Y')
    
    def fecha_con_formato_editar(self):
        return self.fecha_observacion.strftime('%Y/%m/%d')
    
    def extraer_mes(self):
        meses = {
            '01': 'enero', '02': 'febrero', '03': 'marzo', '04': 'abril',
            '05': 'mayo', '06': 'junio', '07': 'julio', '08': 'agosto',
            '09': 'septiembre', '10': 'octubre', '11': 'noviembre', '12': 'diciembre'
        }
        fecha_formateada = self.fecha_observacion.strftime('%d/%m/%Y')
        dia, mes_num, anio = fecha_formateada.split('/')
        mes_nombre = meses[mes_num]
        return dia, mes_nombre, anio


    @staticmethod
    def validar_formulario_avistamientos(data):
        es_valido = True
        if len(data['localidad'])<3:
            flash("Por favor inserte una localidad válida de 3 caracteres o más.","error_localidad")
            es_valido = False
        if len(data['descripcion'])<3:
            flash("Por favor inserte una descripción válida de 3 caracteres o más.","error_descripcion")
            es_valido = False
        if data['fecha_observacion']=="":
            flash("Proporcione una fecha de observación","error_fecha_observacion")
            es_valido = False
        if data['sasquatches']=="":
            flash("Proporcione una cantidad de avistamientos","error_sasquatches")
            es_valido = False
        return es_valido


